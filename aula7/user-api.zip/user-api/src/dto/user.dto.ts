interface UserDTO{
    id? : number;
    nome: string;
    email: string;
    documento: string;
}

export default UserDTO;