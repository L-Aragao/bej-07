export default {
    HOST: 'localhost',
    USER: 'root',
    PASSWORD: 'password'
}